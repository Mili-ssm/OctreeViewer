# R3 compact node-cell CPU comparison

## Protocol and limits

Serial runs used the two prebuilt binaries, the same perf-class binaries and input `.oct`/`.octattrs` files, with full traversal (`max_rows=0`) and `/usr/bin/time -v`. Belvedere had one warmup per binary followed by three alternating pairs (B/C, C/B, B/C); Majadas had one sequential baseline/compact pair. Every process returned 0. Full stdout, stderr, GNU time output, return code, and timeline are retained beside this file.

No cargo/rustc/valgrind or competing benchmark process was present before timing; lab compilation/tests had stopped. The initial load average was 0.76 / 1.40 / 1.39. Processes were allowed on CPUs 0–19; no CPU pinning or isolation was enforced, so host scheduling/interference remains possible. These are CPU traversal measurements only, not browser, GPU, or end-to-end rendering evidence. Treat observed time differences as samples, not a general speed claim.

## Results

| Dataset | Baseline → compact | Cells (both) | Nominal peak scratch (baseline → compact) | Peak RSS (baseline → compact) |
|---|---:|---:|---:|---:|
| Belvedere | 53.88 / 53.61 / 53.60 s → 47.45 / 47.40 / 47.40 s; medians 53.61 → 47.40 s; paired compact/base ratios 0.880–0.884 | 232,396,472 | 11,547,600 → 6,928,560 B | 70,440 / 70,524 / 70,704 → 65,828 / 65,264 / 65,644 kB (medians 70,524 → 65,644 kB) |
| Majadas | 361.66 → 311.70 s; single-pair ratio 0.862 | 1,384,873,569 | 30,226,800 → 18,136,080 B | 230,224 → 218,400 kB |

Both implementations produced identical cell totals and CPU/GPU payload totals per dataset. Nominal scratch figures are the program's reported payload estimates, not allocation capacity or RSS. The `.stderr` evidence confirms paged traversal verified all 24,091 Majadas hierarchy node IDs for both runs.

## Fingerprints and environment

See `metadata.txt` for allowlisted OS/toolchain/CPU/affinity/load metadata and SHA-256 values for binaries, inputs, and source patch. Binary hashes: baseline `d72d4f7655e722012b318dd8ea46d98d58eaf3f464ef1cc964cf9b88319567b6`; compact `9a7daf7bb9171e3c9438a15b3951eee01f3784ae7f8e2183bdfa2e07e4449f8a`.
