#!/usr/bin/env bash
set -u
out=/tmp/r3-layout-comparison-05-11-2026
base=/tmp/r3-adaptive-benchmark/subregions-fast-node-cells
compact=/tmp/r3-layout-narrow-node-cells
bel=/home/<user>/.cache/codex-worktrees/octree-r3-v75/target/render-data/belvedere-v75.oct
maj=/home/<user>/.cache/codex-worktrees/octree-r3-v75/target/render-data/majadas-v75.oct
run() {
  name=$1 bin=$2 data=$3
  printf '%s START %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$name" | tee -a "$out/timeline.txt"
  /usr/bin/time -v -o "$out/$name.time" "$bin" "$data" 0 >"$out/$name.stdout" 2>"$out/$name.stderr"
  rc=$?
  printf '%s\n' "$rc" > "$out/$name.rc"
  printf '%s END rc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$name" "$rc" | tee -a "$out/timeline.txt"
  if [ "$rc" -ne 0 ]; then return "$rc"; fi
}
run bel_warm_base "$base" "$bel" || exit $?
run bel_warm_compact "$compact" "$bel" || exit $?
run bel_pair1_base "$base" "$bel" || exit $?
run bel_pair1_compact "$compact" "$bel" || exit $?
run bel_pair2_compact "$compact" "$bel" || exit $?
run bel_pair2_base "$base" "$bel" || exit $?
run bel_pair3_base "$base" "$bel" || exit $?
run bel_pair3_compact "$compact" "$bel" || exit $?
run maj_pair_base "$base" "$maj" || exit $?
run maj_pair_compact "$compact" "$maj" || exit $?
