use std::{cmp::Ordering,collections::BTreeMap,fs::File,mem::size_of};
use viewer_core::DatasetSource;
use viewer_format::{FormatReader,PagedReader};
use viewer_render_wgpu::{CellGrid,representative_depth,representative_depth_for_spacing};

#[derive(Clone,Debug)] struct Input { coord:[u64;3], block:usize, index:usize }
#[derive(Clone)] struct A { high:u128, low:u64, block:usize,index:usize,coord:[u64;3] }
#[derive(Clone)] struct B { low:u64,block:usize,index:usize,coord:[u64;3] }
#[derive(Clone)] struct C { key:[u64;3], block:u32,index:u32 }
#[derive(Clone)] struct D { key:[u64;3], block:u32,index:u32, local:[u16;3] }
fn lowkey(c:[u64;3])->u64 {let mut k=0;for b in 0..21{for (a,v) in c.iter().enumerate(){k|=((v>>b)&1)<<(3*b+2-a);}}k}
fn prod_key(c:[u64;3],single:bool)->(u128,u64){let mut high=0u128;if !single {for b in 0..42{for (a,v) in c.iter().enumerate(){high|=u128::from((v>>(b+21))&1)<<(3*b+2-a);}}}(high,lowkey(c))}
fn key(c:[u64;3])->[u64;3] {let mut k=[0;3];for chunk in 0..3 {for b in 0..21 {for (a,v) in c.iter().enumerate(){k[2-chunk]|=((v>>(21*chunk+b))&1)<<(3*b+2-a);}}}k}
fn decode(k:[u64;3])->[u64;3] {let mut c=[0;3];for b in 0..63 {for (a,v) in c.iter_mut().enumerate(){let bit=3*b+(2-a);*v|=((k[2-bit/63]>>(bit%63))&1)<<b;}}c}
fn exact(a:&Input,b:&Input)->Ordering {for bit in (0..63).rev(){for axis in 0..3{let ord=((a.coord[axis]>>bit)&1).cmp(&((b.coord[axis]>>bit)&1));if !ord.is_eq(){return ord;}}} (a.block,a.index).cmp(&(b.block,b.index))}
fn verify(input:&[Input])->Result<(),String>{
 let mut reference=input.to_vec();reference.sort_unstable_by(exact);
 let mut tuple:Vec<_>=input.iter().map(|p|{let k=key(p.coord);((((k[0] as u128)<<63)|k[1] as u128,k[2]),p.block,p.index,p.coord)}).collect();tuple.sort_unstable_by_key(|p|(p.0,p.1,p.2));
 let mut aa:Vec<_>=input.iter().map(|p|{let k=key(p.coord);A{high:((k[0] as u128)<<63)|k[1] as u128,low:k[2],block:p.block,index:p.index,coord:p.coord}}).collect();aa.sort_unstable_by_key(|p|(p.high,p.low,p.block,p.index));
 let mut regions:BTreeMap<[u64;3],Vec<B>>=BTreeMap::new();for p in input {let mut k=key(p.coord);let low=k[2];k[2]=0;regions.entry(k).or_default().push(B{low,block:p.block,index:p.index,coord:p.coord});}let mut bb=Vec::new();for (_,mut region) in regions{region.sort_unstable_by_key(|p|(p.low,p.block,p.index));bb.extend(region);}
 let narrow=input.iter().all(|p|p.coord.iter().all(|&v|v < (1 << 21)));
 if narrow { let mut fast:Vec<_>=input.iter().map(|p| B{low:lowkey(p.coord),block:p.block,index:p.index,coord:p.coord}).collect(); fast.sort_unstable_by_key(|p|(p.low,p.block,p.index)); for (p,q) in reference.iter().zip(&fast) {if (p.coord,p.block,p.index)!=(q.coord,q.block,q.index){return Err("narrow flag mismatch".into());}} }
 let mut cc=Vec::new();let mut dd=Vec::new();for p in input {let block=u32::try_from(p.block).map_err(|_|"block overflow")?;let index=u32::try_from(p.index).map_err(|_|"index overflow")?;let k=key(p.coord);cc.push(C{key:k,block,index});dd.push(D{key:k,block,index,local:p.coord.map(|x|(x&0x7fff)as u16)});}
 cc.sort_unstable_by_key(|p|(p.key,p.block,p.index));dd.sort_unstable_by_key(|p|(p.key,p.block,p.index));
 for (i,p) in reference.iter().enumerate(){let t=&tuple[i];let a=&aa[i];let b=&bb[i];let c=&cc[i];let d=&dd[i];let dc=decode_d(d);if (t.3,t.1,t.2)!=(p.coord,p.block,p.index)||(a.coord,a.block,a.index)!=(p.coord,p.block,p.index)||(b.coord,b.block,b.index)!=(p.coord,p.block,p.index)||(decode(c.key),c.block as usize,c.index as usize)!=(p.coord,p.block,p.index)||(dc,d.block as usize,d.index as usize)!=(p.coord,p.block,p.index)||d.local!=dc.map(|v|(v&0x7fff)as u16){return Err(format!("mismatch {i}"));}}
 Ok(())
}
fn timing_enabled(value: Option<std::ffi::OsString>) -> bool { value.is_some() }
fn main()->Result<(),Box<dyn std::error::Error>>{
 println!("scope=per_depth_cpu_lab warmups=3 samples=9 btree_actual_bytes=unknown");
 println!("sizes legacy80_tuple={} A_struct={} B={} C={} D={}",size_of::<((u128,u64),usize,usize,[u64;3])>(),size_of::<A>(),size_of::<B>(),size_of::<C>(),size_of::<D>());
 let paths: Vec<_> = std::env::args().skip(1).collect();
 if paths.len() != 2 || !paths.iter().any(|p| p.contains("majadas-v75.oct")) || !paths.iter().any(|p| p.contains("belvedere-v75.oct")) { return Err("expected exactly the Majadas and Belvedere v75 datasets".into()); }
 for path in paths {let mut reader=FormatReader::new(File::open(&path)?)?;if !reader.has_attributes(){reader.attach_attributes(File::open(format!("{path}attrs"))?)?;}let mut flags=BTreeMap::new();let mut paged=PagedReader::open(File::open(&path)?)?;let mut pages=vec![paged.root_page().clone()];let mut i=0;while i<pages.len(){for n in pages[i].nodes(){flags.insert(n.id(),!n.has_children());}for(a,p) in pages[i].child_pages().collect::<Vec<_>>(){pages.push(paged.read_child_page(a,p)?);}i+=1;}
 let ds=reader.format_metadata().viewer_dataset()?;let hierarchy=ds.hierarchy().clone();let root=hierarchy.stats().root_bounds;let origin=ds.coordinate_frame().origin();let grid=CellGrid{root_min:std::array::from_fn(|a|root.min()[a]-origin[a]),root_side:(0..3).map(|a|root.max()[a]-root.min()[a]).fold(0.,f64::max)};
 let mut nodes:Vec<_>=hierarchy.query(root).collect();nodes.sort_by_key(|n|n.id());let mut selected=Vec::new();let mut leaf=0;let mut internal=0;for node in nodes {let is_leaf=*flags.get(&node.id()).ok_or("missing flag")?;let special=[120259084303u64,124554051592,300647710726].contains(&node.id().get());if !special && (node.point_count()<100 || node.point_count()>100_000 || if is_leaf {leaf>=3}else{internal>=3}){continue;}if !special {if is_leaf {leaf+=1}else{internal+=1}} selected.push(node);}
 if leaf < 3 || internal < 3 { return Err(format!("insufficient selected leaf/internal nodes in {path}: {leaf}/{internal}").into()); }
 let mut wide_ids = Vec::new();
 for n in selected {let b=n.bounds();let min=std::array::from_fn(|a|b.min()[a]-origin[a]);let max=std::array::from_fn(|a|b.max()[a]-origin[a]);let local=viewer_core::SpatialBounds::new(min,max)?;let depth=selected_depth(&grid,local,n.spacing(),flags[&n.id()]);let count=1u64<<depth;let side=grid.root_side/count as f64;let ranges:[(u64,u64);3]=std::array::from_fn(|a|{let last=(count-1)as f64;let lo=((min[a]-grid.root_min[a])/side).round().clamp(0.,last);let hi=(((max[a]-grid.root_min[a])/side).round()-1.).clamp(lo,last);(lo as u64,hi as u64)});
 if ranges.iter().any(|(lo,hi)| hi-lo >= (1 << 21)) { wide_ids.push(n.id().get()); }
 let blocks = n.blocks().iter().map(|id| reader.read_block(*id)).collect::<Result<Vec<_>, _>>()?; let mut input=Vec::new();for (bi,block) in blocks.iter().enumerate(){for (pi,p) in block.points().points().iter().enumerate(){if !p.position.iter().all(|v|v.is_finite()){continue;}let coord=std::array::from_fn(|a|{let absolute=(((f64::from(p.position[a])-grid.root_min[a])/grid.root_side*count as f64).floor().clamp(ranges[a].0 as f64,ranges[a].1 as f64)) as u64;absolute-ranges[a].0});input.push(Input{coord,block:bi,index:pi});}}
 verify(&input)?;
 use viewer_render_wgpu::NodeCellSource;
 let production = viewer_render_wgpu::PointNodeCellSource { min_growth: 1.0 }.node_cells(&grid, n.id(), local, n.spacing(), flags[&n.id()], &blocks)?;
 let expected = production.levels.iter().find(|level| level.depth == depth).ok_or("missing production level")?;
 let actual = lab_level(&grid, local, &blocks, depth, false);
 assert_cells_equal(&actual, &expected.cells)?;
 let compact = lab_level(&grid, local, &blocks, depth, true);
 assert_cells_equal(&compact, &expected.cells)?;
 let (fast48, _) = run_fast48(&grid, local, &blocks, depth, true);
 assert_cells_equal(&fast48, &expected.cells)?;
 assert_cells_equal(&run_fast48(&grid, local, &blocks, depth, false).0, &expected.cells)?;
 for bits in [8, 10, 12, 15, 16, 18, 21] { for fast in [false, true] {
     let regions = region_level(&grid, local, &blocks, depth, bits, fast);
     assert_cells_equal(&regions, &expected.cells)?;
 } }
 if timing_enabled(std::env::var_os("R3_PHASED_TIMING")) {
     const WARMUPS: usize = 3;
     const REPEATS: usize = 9;
     let widths = [8_u8, 10, 12, 15, 16, 18, 21];
     let mut candidates = vec![(0_u8, false), (0_u8, true)];
     for width in widths { candidates.push((width, false)); candidates.push((width, true)); }
     // This run only records capacities and directory entries. Its timings are discarded.
     for &(width, fast) in candidates.iter().filter(|(width, _)| *width != 0) {
         let (cells, audit) = region_run(&grid, local, &blocks, depth, width, fast, true);
         assert_cells_equal(&cells, &expected.cells)?;
         println!("region_audit path={path} node={} width={width} fast={fast} single={} regions={} entries_capacity={} entries_bytes={} directory_live_payload_lower_bound={} btree_actual_bytes=unknown attrs_bytes={} cells_capacity={} cells_bytes={}", n.id().get(), audit.single, audit.regions, audit.entries_capacity, audit.entries_bytes, audit.directory_live_payload_lower_bound, audit.attrs_bytes, audit.cells_capacity, audit.cells_bytes);
         for (prefix, len, cap) in audit.details { println!("region path={path} node={} width={width} fast={fast} prefix={prefix:?} len={len} capacity={cap}", n.id().get()); }
     }
     for round in 0..(WARMUPS + REPEATS) {
         for slot in 0..candidates.len() {
             let (width, fast) = candidates[(round + slot) % candidates.len()];
             if width == 0 {
                 let (cells, sample) = run_fast48(&grid, local, &blocks, depth, fast);
                 assert_cells_equal(&cells, &expected.cells)?;
                 if round >= WARMUPS { println!("raw path={path} node={} sample={} order={slot} candidate={} entry_layout={} prep_ns={} sort_ns={} consume_ns={} total_ns={} entry_capacity={} entry_bytes={} attrs_bytes={} cells_capacity={} cells_bytes={}", n.id().get(), round-WARMUPS, if fast { "fast48" } else { "legacy80" }, if fast && ranges.iter().all(|(lo, hi)| hi - lo < (1 << 21)) { "u64-48B" } else { "u128_u64-80B" }, sample.prep_ns, sample.sort_ns, sample.consume_ns, sample.total_ns, sample.entry_capacity, sample.entry_bytes, sample.attrs_bytes, sample.cells_capacity, sample.cells_bytes); }
             } else {
                 let (cells, sample) = region_run(&grid, local, &blocks, depth, width, fast, false);
                 assert_cells_equal(&cells, &expected.cells)?;
                 if round >= WARMUPS { println!("raw path={path} node={} sample={} order={slot} candidate=region width={width} fast={fast} single={} prep_ns={} sort_ns={} consume_ns={} total_ns={}", n.id().get(), round-WARMUPS, sample.single, sample.prep_ns, sample.sort_ns, sample.consume_ns, sample.total_ns); }
             }
         }
     }
 }
 let bits=input.iter().flat_map(|p|p.coord).map(|v|64-v.leading_zeros()).max().unwrap_or(0);println!("path={path} node={} leaf={} points={} depth={depth} relative_bits={bits} ranges={ranges:?} verified",n.id().get(),flags[&n.id()],input.len());}
 if path.contains("belvedere-v75.oct") && ![120259084303u64, 124554051592, 300647710726].iter().all(|id| wide_ids.contains(id)) { return Err(format!("missing required wide Belvedere nodes: {wide_ids:?}").into()); }
 println!("selection path={path} internal={internal} leaf={leaf} wide_ids={wide_ids:?}");
 }Ok(())}
#[cfg(test)] mod tests {use super::*;#[test]fn boundaries_order_and_reconstruction(){let values=[0,1,(1<<15)-1,1<<15,(1<<21)-1,1<<21,(1u64<<42)-1,1u64<<42,(1u64<<62), (1u64<<63)-1];let mut input=Vec::new();for (i,v) in values.into_iter().enumerate(){for a in 0..3{let mut coord=[19,31,47];coord[a]=v;input.push(Input{coord,block:i%2,index:i*3+a});}}input.push(Input{coord:[19,31,47],block:1,index:0});input.push(Input{coord:[19,31,47],block:0,index:5});input.push(Input{coord:[19,31,47],block:0,index:1});verify(&input).unwrap();} }

fn selected_depth(grid: &CellGrid, bounds: viewer_core::SpatialBounds, spacing: Option<f64>, is_leaf: bool) -> u8 {
    if is_leaf { spacing.map_or_else(|| representative_depth(grid, bounds), |s| representative_depth_for_spacing(grid, s)) } else { representative_depth(grid, bounds) }
}
#[cfg(test)]
#[test]
fn internal_depth_ignores_leaf_spacing() {
    let grid = CellGrid { root_min: [0.0; 3], root_side: 8.0 };
    let bounds = viewer_core::SpatialBounds::new([0.0; 3], [8.0; 3]).unwrap();
    let spacing = Some(0.25);
    let current = selected_depth(&grid, bounds, spacing, false);
    assert_eq!(current, representative_depth(&grid, bounds));
}

fn assert_cells_equal(a: &[viewer_render_wgpu::NodeCell], b: &[viewer_render_wgpu::NodeCell]) -> Result<(), String> {
    if a.len() != b.len() { return Err(format!("cell count {} != {}", a.len(), b.len())); }
    for (i, (x, y)) in a.iter().zip(b).enumerate() {
        if x.coord != y.coord || x.rgb_sum != y.rgb_sum || x.intensity_sum.to_bits() != y.intensity_sum.to_bits()
            || x.intensity_count != y.intensity_count || x.count != y.count || x.classification != y.classification
            || x.z_min.to_bits() != y.z_min.to_bits() || x.z_max.to_bits() != y.z_max.to_bits() {
            return Err(format!("cell {i}: {x:?} != {y:?}"));
        }
    }
    Ok(())
}

#[path = "../../../crates/viewer_render_wgpu/src/attributes.rs"]
mod attributes;

#[derive(Debug)]
struct PhaseSample { prep_ns: u128, sort_ns: u128, consume_ns: u128, total_ns: u128, entry_capacity: usize, entry_bytes: usize, attrs_bytes: usize, cells_capacity: usize, cells_bytes: usize }

fn run_fast48(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, narrow: bool) -> (Vec<viewer_render_wgpu::NodeCell>, PhaseSample) {
    let started = std::time::Instant::now();
    let count = 1_u64 << depth;
    let side = grid.root_side / count as f64;
    let range: [(u64, u64); 3] = std::array::from_fn(|axis| {
        let edge = |v: f64| ((v - grid.root_min[axis]) / side).round();
        let last = (count - 1) as f64;
        let lo = edge(bounds.min()[axis]).clamp(0.0, last);
        (lo as u64, (edge(bounds.max()[axis]) - 1.0).clamp(lo, last) as u64)
    });
    let single = range.iter().all(|(lo, hi)| hi - lo < (1 << 21));
    if narrow && single {
        run_fast_keyed(grid, blocks, count, range, started, lowkey)
    } else {
        run_fast_keyed(grid, blocks, count, range, started, |relative| prod_key(relative, single))
    }
}

fn run_fast_keyed<K: Copy + Ord>(grid: &CellGrid, blocks: &[viewer_core::PointBlock], count: u64, range: [(u64, u64); 3], started: std::time::Instant, key_for: impl Fn([u64; 3]) -> K) -> (Vec<viewer_render_wgpu::NodeCell>, PhaseSample) {
    use attributes::ScalarAttribute;
    use viewer_render_wgpu::NodeCell;
    let attrs: Vec<_> = blocks.iter().map(|b| (ScalarAttribute::find(b, "intensity"), ScalarAttribute::find(b, "classification"))).collect();
    let mut keyed: Vec<(K, usize, usize, [u64; 3])> = Vec::new();
    for (bi, block) in blocks.iter().enumerate() {
        for (pi, point) in block.points().points().iter().enumerate() {
            if point.position.iter().any(|v| !v.is_finite()) { continue; }
            let coord = std::array::from_fn(|axis| (((f64::from(point.position[axis]) - grid.root_min[axis]) / grid.root_side * count as f64).floor()).clamp(range[axis].0 as f64, range[axis].1 as f64) as u64);
            let relative = std::array::from_fn(|axis| coord[axis] - range[axis].0);
            keyed.push((key_for(relative), bi, pi, coord));
        }
    }
    let entry_capacity = keyed.capacity();
    let entry_bytes = entry_capacity * size_of::<(K, usize, usize, [u64; 3])>();
    let attrs_bytes = attrs.capacity() * size_of::<(Option<ScalarAttribute<'_>>, Option<ScalarAttribute<'_>>)>() ;
    let prepared = std::time::Instant::now();
    keyed.sort_unstable_by_key(|(key, bi, pi, _)| (*key, *bi, *pi));
    let sorted = std::time::Instant::now();
    let mut cells: Vec<NodeCell> = Vec::new();
    let mut current = None;
    for (key, bi, pi, coord) in keyed {
        let p = &blocks[bi].points().points()[pi];
        if current != Some(key) {
            current = Some(key);
            cells.push(NodeCell { coord, rgb_sum: [0; 3], intensity_sum: 0.0, intensity_count: 0, count: 0,
                classification: attrs[bi].1.and_then(|a| a.value_at(pi)).map_or(-1, |v| v as i16), z_min: p.position[2], z_max: p.position[2] });
        }
        let cell = cells.last_mut().unwrap();
        if let Some(value) = attrs[bi].0.and_then(|a| a.value_at(pi)) { cell.intensity_sum += f64::from(value); cell.intensity_count += 1; }
        cell.rgb_sum[0] += u64::from(p.color.r);
        cell.rgb_sum[1] += u64::from(p.color.g);
        cell.rgb_sum[2] += u64::from(p.color.b);
        cell.count += 1;
        cell.z_min = cell.z_min.min(p.position[2]);
        cell.z_max = cell.z_max.max(p.position[2]);
    }
    std::hint::black_box(&cells);
    let consumed = std::time::Instant::now();
    let sample = PhaseSample { prep_ns: prepared.duration_since(started).as_nanos(), sort_ns: sorted.duration_since(prepared).as_nanos(), consume_ns: consumed.duration_since(sorted).as_nanos(), total_ns: consumed.duration_since(started).as_nanos(), entry_capacity, entry_bytes, attrs_bytes, cells_capacity: cells.capacity(), cells_bytes: cells.capacity() * size_of::<NodeCell>() };
    (cells, sample)
}

fn lab_level(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, compact: bool) -> Vec<viewer_render_wgpu::NodeCell> {
    run_level(grid, bounds, blocks, depth, compact, false).0
}

fn run_level(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, compact: bool, fast48: bool) -> (Vec<viewer_render_wgpu::NodeCell>, PhaseSample) {
    let started = std::time::Instant::now();
    use attributes::ScalarAttribute;
    use viewer_render_wgpu::NodeCell;
    let count = 1_u64 << depth;
    let side = grid.root_side / count as f64;
    let ranges: [(u64, u64); 3] = std::array::from_fn(|axis| {
        let edge = |v: f64| ((v - grid.root_min[axis]) / side).round();
        let last = (count - 1) as f64;
        let lo = edge(bounds.min()[axis]).clamp(0.0, last);
        (lo as u64, (edge(bounds.max()[axis]) - 1.0).clamp(lo, last) as u64)
    });
    let single = ranges.iter().all(|(lo, hi)| hi - lo < (1 << 21));
    let attrs: Vec<_> = blocks.iter().map(|b| (ScalarAttribute::find(b, "intensity"), ScalarAttribute::find(b, "classification"))).collect();
    let mut keyed: Vec<((u128, u64), usize, usize, [u64; 3])> = Vec::new();
    let mut compact_entries: Vec<D> = Vec::new();
    let mut narrow_entries: Vec<B> = Vec::new();
    let use_narrow = fast48 && single;
    for (bi, block) in blocks.iter().enumerate() {
        for (pi, point) in block.points().points().iter().enumerate() {
            if point.position.iter().any(|v| !v.is_finite()) { continue; }
            let coord: [u64; 3] = std::array::from_fn(|axis| (((f64::from(point.position[axis]) - grid.root_min[axis]) / grid.root_side * count as f64).floor()).clamp(ranges[axis].0 as f64, ranges[axis].1 as f64) as u64);
            let relative = std::array::from_fn(|axis| coord[axis] - ranges[axis].0);
            if compact {
                compact_entries.push(D { key: key(relative), block: u32::try_from(bi).expect("block index overflow"), index: u32::try_from(pi).expect("point index overflow"), local: relative.map(|v| (v & 0x7fff) as u16) });
            } else if use_narrow {
                narrow_entries.push(B { low: lowkey(relative), block: bi, index: pi, coord });
            } else {
                keyed.push((prod_key(relative, single), bi, pi, coord));
            }
        }
    }
    let entry_capacity = if compact { compact_entries.capacity() } else if use_narrow { narrow_entries.capacity() } else { keyed.capacity() };
    let entry_bytes = entry_capacity * if compact { size_of::<D>() } else if use_narrow { size_of::<B>() } else { size_of::<((u128, u64), usize, usize, [u64; 3])>() };
    let attrs_bytes = attrs.capacity() * size_of::<(Option<ScalarAttribute<'_>>, Option<ScalarAttribute<'_>>)>() ;
    let prepared = std::time::Instant::now();
    let ordered: Box<dyn Iterator<Item = ((u128, u64), usize, usize, [u64; 3])>> = if compact {
        compact_entries.sort_unstable_by_key(|d| (d.key, d.block, d.index));
        Box::new(compact_entries.into_iter().map(move |d| {
            let relative = decode_d(&d);
            let coord = std::array::from_fn(|axis| relative[axis] + ranges[axis].0);
            ((((d.key[0] as u128) << 63) | d.key[1] as u128, d.key[2]), d.block as usize, d.index as usize, coord)
        }))
    } else if use_narrow {
        narrow_entries.sort_unstable_by_key(|p| (p.low, p.block, p.index));
        Box::new(narrow_entries.into_iter().map(|p| ((0, p.low), p.block, p.index, p.coord)))
    } else {
        keyed.sort_unstable_by_key(|(key, bi, pi, _)| (*key, *bi, *pi));
        Box::new(keyed.into_iter())
    };
    let sorted = std::time::Instant::now();
    let mut cells: Vec<NodeCell> = Vec::new();
    let mut current = None;
    for (key, bi, pi, coord) in ordered {
        let p = &blocks[bi].points().points()[pi];
        if current != Some(key) {
            current = Some(key);
            cells.push(NodeCell { coord, rgb_sum: [0; 3], intensity_sum: 0.0, intensity_count: 0, count: 0,
                classification: attrs[bi].1.and_then(|a| a.value_at(pi)).map_or(-1, |v| v as i16), z_min: p.position[2], z_max: p.position[2] });
        }
        let cell = cells.last_mut().unwrap();
        if let Some(value) = attrs[bi].0.and_then(|a| a.value_at(pi)) { cell.intensity_sum += f64::from(value); cell.intensity_count += 1; }
        cell.rgb_sum[0] += u64::from(p.color.r);
        cell.rgb_sum[1] += u64::from(p.color.g);
        cell.rgb_sum[2] += u64::from(p.color.b);
        cell.count += 1;
        cell.z_min = cell.z_min.min(p.position[2]);
        cell.z_max = cell.z_max.max(p.position[2]);
    }
    std::hint::black_box(&cells);
    let consumed = std::time::Instant::now();
    let sample = PhaseSample { prep_ns: prepared.duration_since(started).as_nanos(), sort_ns: sorted.duration_since(prepared).as_nanos(), consume_ns: consumed.duration_since(sorted).as_nanos(), total_ns: consumed.duration_since(started).as_nanos(), entry_capacity, entry_bytes, attrs_bytes, cells_capacity: cells.capacity(), cells_bytes: cells.capacity() * size_of::<NodeCell>() };
    (cells, sample)
}

#[cfg(test)]
#[test]
fn aggregate_matches_production_for_duplicate_points_in_multiple_blocks() {
    use viewer_core::{BlockId, ColorRgb, NodeId, Point, PointBatch, PointBlock, SpatialBounds};
    use viewer_render_wgpu::{NodeCellSource, PointNodeCellSource};
    let grid = CellGrid { root_min: [0.0; 3], root_side: 8.0 };
    let bounds = SpatialBounds::new([0.0; 3], [8.0; 3]).unwrap();
    let blocks: Vec<_> = (0..2).map(|i| PointBlock::new(BlockId::new(i), PointBatch::new(vec![Point::new([1.0, 2.0, 3.0], ColorRgb::new(1, 2, 3))]), vec![])).collect();
    let source = PointNodeCellSource { min_growth: 1.0 };
    let production = source.node_cells(&grid, NodeId::new(0), bounds, None, false, &blocks).unwrap();
    let depth = representative_depth(&grid, bounds);
    let expected = production.levels.iter().find(|level| level.depth == depth).unwrap();
    assert_cells_equal(&lab_level(&grid, bounds, &blocks, depth, false), &expected.cells).unwrap();
    assert_cells_equal(&lab_level(&grid, bounds, &blocks, depth, true), &expected.cells).unwrap();
    assert_eq!(size_of::<(u64, usize, usize, [u64; 3])>(), 48);
    let (_, sample) = run_fast48(&grid, bounds, &blocks, depth, true);
    assert_eq!(sample.entry_bytes, sample.entry_capacity * 48);
    assert_cells_equal(&run_fast48(&grid, bounds, &blocks, depth, true).0, &expected.cells).unwrap();
}

fn decode_d(d: &D) -> [u64; 3] { let high = decode(d.key); std::array::from_fn(|axis| (high[axis] & !0x7fff) | u64::from(d.local[axis])) }

#[cfg(test)]
#[test]
fn compact_reconstruction_reads_stored_u16_lows() {
    let d = D { key: key([5, 8, 9]), block: 0, index: 0, local: [1, 2, 3] };
    assert_eq!(decode_d(&d), [1, 2, 3]);
}

#[cfg(test)]
#[test]
fn mixed_attributes_nonfinite_positions_and_signed_zero_match_production() {
    use viewer_core::{AttributeColumn, AttributeDataType, AttributeDescriptor, AttributeValues, BlockId, ColorRgb, NodeId, Point, PointBatch, PointBlock, SpatialBounds};
    use viewer_render_wgpu::{NodeCellSource, PointNodeCellSource};
    let grid = CellGrid { root_min: [-4.0; 3], root_side: 8.0 };
    let bounds = SpatialBounds::new([-4.0; 3], [4.0; 3]).unwrap();
    let points = vec![Point::new([0.0, 0.0, -0.0], ColorRgb::new(1,2,3)), Point::new([0.0, 0.0, 0.0], ColorRgb::new(5,6,7)), Point::new([f32::NAN, 0.0, 0.0], ColorRgb::new(9,9,9))];
    let intensity = AttributeColumn::new(AttributeDescriptor::new("Intensity", AttributeDataType::F32, 1).unwrap(), AttributeValues::F32(vec![1.5, -2.0, 4.0]), 3).unwrap();
    let classification = AttributeColumn::new(AttributeDescriptor::new("classification", AttributeDataType::U8, 1).unwrap(), AttributeValues::U8(vec![7, 2, 9]), 3).unwrap();
    let blocks = vec![PointBlock::new(BlockId::new(0), PointBatch::new(points), vec![intensity, classification]), PointBlock::new(BlockId::new(1), PointBatch::new(vec![Point::new([0.0;3], ColorRgb::new(1,1,1))]), vec![])];
    let source = PointNodeCellSource { min_growth: 1.0 };
    let production = source.node_cells(&grid, NodeId::new(0), bounds, None, false, &blocks).unwrap();
    let depth = representative_depth(&grid, bounds);
    let expected = &production.levels.iter().find(|level| level.depth == depth).unwrap().cells;
    assert_eq!(expected.len(), 1);
    assert_eq!((expected[0].count, expected[0].intensity_count, expected[0].classification), (3, 2, 7));
    for compact in [false, true] { assert_cells_equal(&lab_level(&grid, bounds, &blocks, depth, compact), expected).unwrap(); }
    for bits in [8, 10, 12, 15, 16, 18, 21] { for fast in [false, true] {
        let (cells, audit) = region_run(&grid, bounds, &blocks, depth, bits, fast, true);
        assert_cells_equal(&cells, expected).unwrap();
        assert_eq!(audit.regions, 1);
        assert_eq!(audit.details[0].1, 3);
        assert!(audit.entries_capacity >= 3);
        let (cells, sample) = region_run(&grid, bounds, &blocks, depth, bits, fast, false);
        assert_cells_equal(&cells, expected).unwrap();
        assert!(sample.details.is_empty());
    } }
}

trait LocalKey: Copy + Ord {
    fn from_u64(value: u64) -> Self;
    fn into_u64(self) -> u64;
}
impl LocalKey for u32 {
    fn from_u64(value: u64) -> Self { u32::try_from(value).expect("local key overflow") }
    fn into_u64(self) -> u64 { u64::from(self) }
}
impl LocalKey for u64 {
    fn from_u64(value: u64) -> Self { value }
    fn into_u64(self) -> u64 { self }
}

enum Regions<T> { Single(Vec<(T, u32, u32)>), Many(BTreeMap<[u64; 3], Vec<(T, u32, u32)>>) }

#[derive(Debug)]
struct RegionSample {
    prep_ns: u128, sort_ns: u128, consume_ns: u128, total_ns: u128,
    regions: usize, entries_capacity: usize, entries_bytes: usize,
    directory_live_payload_lower_bound: usize, attrs_bytes: usize, single: bool,
    cells_capacity: usize, cells_bytes: usize,
    details: Vec<([u64; 3], usize, usize)>,
}

fn region_level(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, bits: u8, fast: bool) -> Vec<viewer_render_wgpu::NodeCell> {
    region_run(grid, bounds, blocks, depth, bits, fast, false).0
}

fn region_run(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, bits: u8, fast: bool, audit: bool) -> (Vec<viewer_render_wgpu::NodeCell>, RegionSample) {
    assert!((1..=21).contains(&bits));
    if bits <= 10 { region_level_t::<u32>(grid, bounds, blocks, depth, bits, fast, audit) }
    else { region_level_t::<u64>(grid, bounds, blocks, depth, bits, fast, audit) }
}

fn region_level_t<T: LocalKey>(grid: &CellGrid, bounds: viewer_core::SpatialBounds, blocks: &[viewer_core::PointBlock], depth: u8, bits: u8, fast: bool, audit: bool) -> (Vec<viewer_render_wgpu::NodeCell>, RegionSample) {
    use attributes::ScalarAttribute;
    use viewer_render_wgpu::NodeCell;
    let started = std::time::Instant::now();
    let count = 1_u64 << depth;
    let side = grid.root_side / count as f64;
    let ranges: [(u64, u64); 3] = std::array::from_fn(|axis| {
        let edge = |v: f64| ((v - grid.root_min[axis]) / side).round();
        let last = (count - 1) as f64;
        let lo = edge(bounds.min()[axis]).clamp(0.0, last);
        (lo as u64, (edge(bounds.max()[axis]) - 1.0).clamp(lo, last) as u64)
    });
    let one_region = fast && ranges.iter().all(|(lo, hi)| hi - lo < (1_u64 << bits));
    let mut regions = if one_region { Regions::Single(Vec::new()) } else { Regions::Many(BTreeMap::new()) };
    let mask = (1_u64 << bits) - 1;
    let attrs: Vec<_> = blocks.iter().map(|b| (ScalarAttribute::find(b, "intensity"), ScalarAttribute::find(b, "classification"))).collect();
    for (bi, block) in blocks.iter().enumerate() {
        for (pi, point) in block.points().points().iter().enumerate() {
            if point.position.iter().any(|v| !v.is_finite()) { continue; }
            let relative: [u64; 3] = std::array::from_fn(|axis| {
                let coord = (((f64::from(point.position[axis]) - grid.root_min[axis]) / grid.root_side * count as f64).floor()).clamp(ranges[axis].0 as f64, ranges[axis].1 as f64) as u64;
                coord - ranges[axis].0
            });
            let low = lowkey(relative.map(|v| v & mask));
            let item = (T::from_u64(low), u32::try_from(bi).expect("block index overflow"), u32::try_from(pi).expect("point index overflow"));
            match &mut regions {
                Regions::Single(entries) => entries.push(item),
                Regions::Many(map) => map.entry(key(relative.map(|v| v >> bits))).or_default().push(item),
            }
        }
    }
    // Auditing is a separate untimed invocation; do not add its allocations to timed samples.
    let mut details = Vec::new();
    if audit {
        match &regions {
            Regions::Single(entries) => details.push(([0; 3], entries.len(), entries.capacity())),
            Regions::Many(map) => for (prefix, entries) in map { details.push((*prefix, entries.len(), entries.capacity())); },
        }
    }
    let prepared = std::time::Instant::now();
    match &mut regions {
        Regions::Single(entries) => entries.sort_unstable(),
        Regions::Many(map) => for entries in map.values_mut() { entries.sort_unstable(); },
    }
    let sorted = std::time::Instant::now();
    let mut cells: Vec<NodeCell> = Vec::new();
    let mut consume = |prefix: [u64; 3], entries: Vec<(T, u32, u32)>| {
        let region_coord = decode(prefix);
        let mut current = None;
        for (local, bi, pi) in entries {
            let local = local.into_u64();
            let p = &blocks[bi as usize].points().points()[pi as usize];
            if current != Some(local) {
                current = Some(local);
                let low = decode([0, 0, local]);
                let coord = std::array::from_fn(|axis| ((region_coord[axis] << bits) | low[axis]) + ranges[axis].0);
                cells.push(NodeCell { coord, rgb_sum: [0; 3], intensity_sum: 0.0, intensity_count: 0, count: 0,
                    classification: attrs[bi as usize].1.and_then(|a| a.value_at(pi as usize)).map_or(-1, |v| v as i16), z_min: p.position[2], z_max: p.position[2] });
            }
            let cell = cells.last_mut().unwrap();
            if let Some(value) = attrs[bi as usize].0.and_then(|a| a.value_at(pi as usize)) { cell.intensity_sum += f64::from(value); cell.intensity_count += 1; }
            cell.rgb_sum[0] += u64::from(p.color.r);
            cell.rgb_sum[1] += u64::from(p.color.g);
            cell.rgb_sum[2] += u64::from(p.color.b);
            cell.count += 1;
            cell.z_min = cell.z_min.min(p.position[2]);
            cell.z_max = cell.z_max.max(p.position[2]);
        }
    };
    match regions {
        Regions::Single(entries) => consume([0; 3], entries),
        Regions::Many(map) => for (prefix, entries) in map { consume(prefix, entries); },
    }
    std::hint::black_box(&cells);
    let consumed = std::time::Instant::now();
    let regions_count = details.len();
    let entries_capacity = details.iter().map(|(_, _, cap)| cap).sum::<usize>();
    let sample = RegionSample {
        prep_ns: prepared.duration_since(started).as_nanos(), sort_ns: sorted.duration_since(prepared).as_nanos(),
        consume_ns: consumed.duration_since(sorted).as_nanos(), total_ns: consumed.duration_since(started).as_nanos(),
        regions: regions_count, entries_capacity, entries_bytes: entries_capacity * size_of::<(T, u32, u32)>(),
        directory_live_payload_lower_bound: if one_region { 0 } else { regions_count * (size_of::<[u64; 3]>() + size_of::<Vec<(T, u32, u32)>>()) },
        attrs_bytes: attrs.capacity() * size_of::<(Option<ScalarAttribute<'_>>, Option<ScalarAttribute<'_>>)>() ,
        single: one_region, cells_capacity: cells.capacity(), cells_bytes: cells.capacity() * size_of::<NodeCell>(), details,
    };
    (cells, sample)
}

#[cfg(test)]
#[test]
fn partitioned_regions_match_production_for_all_widths_and_duplicates() {
    use viewer_core::{BlockId, ColorRgb, NodeId, Point, PointBatch, PointBlock, SpatialBounds};
    use viewer_render_wgpu::{NodeCellSource, PointNodeCellSource};
    let grid = CellGrid { root_min: [0.0; 3], root_side: 8.0 };
    let bounds = SpatialBounds::new([0.0; 3], [8.0; 3]).unwrap();
    let blocks: Vec<_> = (0..2).map(|i| PointBlock::new(BlockId::new(i), PointBatch::new(vec![Point::new([1.0, 2.0, 3.0], ColorRgb::new(1, 2, 3))]), vec![])).collect();
    let production = PointNodeCellSource { min_growth: 1.0 }.node_cells(&grid, NodeId::new(0), bounds, None, false, &blocks).unwrap();
    let depth = representative_depth(&grid, bounds);
    let expected = &production.levels.iter().find(|level| level.depth == depth).unwrap().cells;
    for bits in [8, 10, 12, 15, 16, 18, 21] { for fast in [false, true] { assert_cells_equal(&region_level(&grid, bounds, &blocks, depth, bits, fast), expected).unwrap(); } }
}

#[cfg(test)]
#[test]
fn partition_boundaries_and_sparse_regions_preserve_order() {
    use viewer_core::{BlockId, ColorRgb, Point, PointBatch, PointBlock, SpatialBounds};
    let grid = CellGrid { root_min: [0.0; 3], root_side: 1.0 };
    let bounds = SpatialBounds::new([0.0; 3], [1.0; 3]).unwrap();
    for depth in [30, 42, 63] {
        let scale = 2.0_f64.powi(-i32::from(depth));
        let mut coords = vec![0.0f32];
        for bit in [8, 10, 12, 15, 16, 18, 21] {
            for offset in [-1_i64, 0, 1] {
                coords.push((((1_i64 << bit) + offset) as f64 * scale) as f32);
            }
        }
        coords.extend([0.25, 0.5, 0.75]);
        let blocks = (0..2).map(|id| PointBlock::new(BlockId::new(id), PointBatch::new(coords.iter().enumerate().map(|(i, value)| Point::new([*value, coords[(i * 7) % coords.len()], *value], ColorRgb::new(i as u8, id as u8, 3))).collect()), vec![])).collect::<Vec<_>>();
        let expected = lab_level(&grid, bounds, &blocks, depth, false);
        let (fallback, sample) = run_fast48(&grid, bounds, &blocks, depth, true);
        assert_cells_equal(&fallback, &expected).unwrap();
        assert_eq!(sample.entry_bytes, sample.entry_capacity * size_of::<((u128, u64), usize, usize, [u64; 3])>());
        for bits in [8, 10, 12, 15, 16, 18, 21] { for fast in [false, true] {
            assert_cells_equal(&region_level(&grid, bounds, &blocks, depth, bits, fast), &expected).unwrap();
        } }
    }
}

#[cfg(test)]
#[test]
fn timing_gate_requires_explicit_environment_flag() {
    assert!(!timing_enabled(None));
    assert!(timing_enabled(Some("1".into())));
}
